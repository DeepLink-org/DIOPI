var searchData=
[
  ['diopistreamhandle_5ft',['diopiStreamHandle_t',['../diopirt_8h.html#a978d34b7c4c1c748d80e55092ec56f4e',1,'diopirt.h']]]
];
