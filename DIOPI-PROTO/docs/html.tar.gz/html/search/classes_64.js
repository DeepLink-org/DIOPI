var searchData=
[
  ['diopiscalar_5ft',['diopiScalar_t',['../structdiopiScalar__t.html',1,'']]],
  ['diopisize_5ft_5f',['diopiSize_t_',['../structdiopiSize__t__.html',1,'']]]
];
